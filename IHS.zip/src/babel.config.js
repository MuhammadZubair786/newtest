module.exports = function (api) {
    return {
      plugins: ['macros'],
      'fontawesome-svg-core': {
        'license': 'free'
      }
    }
  }
  